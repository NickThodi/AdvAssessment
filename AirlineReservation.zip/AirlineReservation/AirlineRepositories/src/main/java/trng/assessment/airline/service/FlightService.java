package trng.assessment.airline.service;

import java.util.List;

import trng.assessment.airline.Flight;
import trng.assessment.excp.FlightNotFoundException;


public interface FlightService {
	void addFlight(Flight flight);
	void updateFlight(Flight flight) throws  FlightNotFoundException;
	Flight loadFlight(String airlineName);
	List<Flight> loadFlights(String airlineName);
	List<Flight> loadFlights();
	List<String> loadFlightNames();
	Flight loadFlightById(int flightId) throws FlightNotFoundException;
	boolean deleteFlight(int flightId) throws FlightNotFoundException;
}
