package trng.assessment.excp;

public class FlightNotFoundException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FlightNotFoundException() {
		super();
	}

	public FlightNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public FlightNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public FlightNotFoundException(String message) {
		super(message);
	}

	public FlightNotFoundException(Throwable cause) {
		super(cause);
	}
}
