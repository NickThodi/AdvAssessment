package trng.assessment.airline.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomBooleanEditor;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import trng.assessment.airline.Flight;
import trng.assessment.airline.service.FlightService;
import trng.assessment.airline.service.GeographicalService;
import trng.assessment.excp.FlightNotFoundException;


public class FlightController {

    final static Logger logger = Logger.getLogger(FlightController.class);
    String formName = "UserRegistration";

    @Autowired
    private FlightService userService;

    @Autowired
    GeographicalService geographicalService;



    @InitBinder
    protected void initBinder(WebDataBinder binder) {

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        dateFormat.setLenient(false);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
        
  
        binder.registerCustomEditor(String.class, "salaried", new CustomBooleanEditor(CustomBooleanEditor.VALUE_YES, CustomBooleanEditor.VALUE_NO, false));
    }

    @InitBinder("userInfo") //If required Another binder for different command/form 
    protected void userInfoInitBinder(WebDataBinder binder) {
        logger.debug("initBinder method called");
        //init binders for userInfo
    }
    @ModelAttribute
    public Flight addFlight(ModelMap model) {
        logger.debug("@ModelAttribute addUser method called");
        model.addAttribute("countryCodes", geographicalService.getCountryCodes());
        return new Flight();
    }

    @RequestMapping(method = RequestMethod.GET)
    public String homePage() {
        logger.debug("defaultPage method called");
        return "userOperations";
    }
    
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String defaultPage() {
        logger.debug("defaultPage method called");
        return formName;
    }

    @RequestMapping(value = "/new", method = RequestMethod.GET)
    public String populateModel() {
        return "forword:/user/";
    }

    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public String searchUser() {
        logger.debug("defaultPage method called");
        return "searchUser";
    }

    @RequestMapping(value = "/listUsers", method = RequestMethod.GET)
    public ModelAndView listUsers() {
        logger.debug("listUsers method called");
        ModelAndView modelAndView = new ModelAndView("FlightList");
        modelAndView.addObject("users", userService.loadFlights());
        return modelAndView;
    }
    
    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String registerUserInfo(@RequestParam int flightId, @RequestParam int airlineId,
                                   @RequestParam String airlineName, @RequestParam Date arrivalTime, @RequestParam Date departureTime,
                                   @RequestParam String country, @RequestParam float anualSalary) {
       
        Flight flight = new Flight();
        flight.setFlightId(flightId);
        flight.setAirlineId(airlineId);
        flight.setAirlineName(airlineName);
        flight.setArrivalTime(arrivalTime);
        flight.setDepartureTime(departureTime);

        return formName;
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ModelAndView registerUser(@ModelAttribute("user") @Valid Flight flight, BindingResult result) {
        logger.debug("registerUser method called " + flight);

        ModelAndView modelAndView = new ModelAndView(formName);
        modelAndView.addObject("countryCodes", geographicalService.getCountryCodes());
        if (result.hasErrors()) {
            return modelAndView;
        } else {
            userService.addFlight(flight);
            modelAndView.addObject("user", new Flight());
            modelAndView.addObject("message", "Successfully Registered");
            return modelAndView;
        }
    }

    @RequestMapping(value = "/load", method = RequestMethod.GET)
    public ModelAndView loadUser(@RequestParam int flightId) throws FlightNotFoundException {
        logger.debug("loadUser method called with userId: " + flightId);

        ModelAndView modelandView = new ModelAndView("viewUser");
        Flight user = userService.loadFlightById(flightId);
        modelandView.addObject("user", user);
        return modelandView;
    }

    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public ModelAndView deleteUser(@RequestParam int flightId) throws FlightNotFoundException {
        logger.debug("loadUser method called");

        ModelAndView modelandView = new ModelAndView("viewUser");
        boolean deleted = userService.deleteFlight(flightId);
        return modelandView;
    }
    
    @ExceptionHandler(FlightNotFoundException.class)
    public ModelAndView handleUserNotFoundException(FlightNotFoundException ex) {
        ModelAndView modelAndView = new ModelAndView("error");
        modelAndView.addObject("exception", ex);
        return modelAndView;
    }

    @RequestMapping(value = "/showCookie", method = RequestMethod.GET)
    public void displayCookieInfo(@CookieValue("JSESSIONID") String sessionCookie) {
        logger.debug("sessionCookie: " + sessionCookie);
    }

    @RequestMapping(value = "/ajaxUserOperations", method = RequestMethod.GET)
    public String ajaxUserOperations(@CookieValue("JSESSIONID") String sessionCookie) {
    	return "ajaxUserOperations";
    }
}
