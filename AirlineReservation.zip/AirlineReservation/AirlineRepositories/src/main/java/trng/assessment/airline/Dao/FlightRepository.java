package trng.assessment.airline.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import trng.assessment.airline.Flight;


public interface FlightRepository extends JpaRepository<Flight, Long> {
    Flight findByAirlineName(String airlineName);
}
