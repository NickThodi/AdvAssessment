package trng.assessment.airline.Dao;

import java.util.List;

import trng.assessment.airline.Flight;
import trng.assessment.excp.FlightNotFoundException;


public interface FlightDao {
	void save(Flight user);
	Flight findFlightByName(String airlineName);
	List<Flight> findFlightByAirlineNameStartsWith(String airlineName);
	List<Flight> findAllFlights();
	List<String> findAllFlightsByNames();
	Flight findFlightById(int flightId) throws FlightNotFoundException;
	boolean deleteFlight(int flightId);
}
