package trng.assessment.airline.service;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import trng.assessment.airline.Flight;
import trng.assessment.airline.Dao.FlightDao;
import trng.assessment.excp.FlightNotFoundException;


@Service
public class FlightServiceImpl implements FlightService {
    final static Logger logger = Logger.getLogger(FlightServiceImpl.class);
	
    AtomicInteger atomicInteger = new AtomicInteger(3); 
    
	@Autowired
	private FlightDao flightDao; 
	
	private Flight flight;
	
	@Override
	@Transactional
	public void addFlight(Flight flight) {
		flight.setFlightId(atomicInteger.incrementAndGet());
		flight.setAirlineName(String.valueOf(atomicInteger.incrementAndGet()));
		flightDao.save(flight);
	}

	@Override
	@Transactional(readOnly = true)
	public Flight loadFlight(String airlineName) {
		return flightDao.findFlightByName(airlineName);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Flight> loadFlights(String airlineName) {
		return flightDao.findFlightByAirlineNameStartsWith(airlineName);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Flight> loadFlights() {
		return flightDao.findAllFlights();
	}

	@Override
	@Transactional(readOnly = true)
	public List<String> loadFlightNames() {
		return flightDao.findAllFlightsByNames();
	}

	@Override
	@Transactional(readOnly = true)
	public Flight loadFlightById(int flightId) throws FlightNotFoundException {
		return flightDao.findFlightById(flightId);
	}
	
	@Override
	public boolean deleteFlight(int flightId) throws FlightNotFoundException {
		if (flightDao.findFlightById(flightId) != null) { 
			return flightDao.deleteFlight(flightId);
		} else {
			return false;
		}
	}

	@Override
	public void updateFlight(Flight flight) throws FlightNotFoundException {
		if (flightDao.findFlightById(flight.getFlightId()) != null) { 
			flightDao.save(flight);
		} else {
			throw new FlightNotFoundException();
		}
		
	}

}
