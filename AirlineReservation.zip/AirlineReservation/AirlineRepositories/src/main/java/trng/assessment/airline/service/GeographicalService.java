package trng.assessment.airline.service;

import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class GeographicalService {

	public static Map<String, String> getCountryCodes() {
		
		Map<String,String> country = new LinkedHashMap<String,String>();
		country.put("US", "United Stated");
		country.put("CHINA", "China");
		country.put("SG", "Singapore");
		country.put("MY", "Malaysia");
		
		return country;
	}

	public static Map<String, String> getStates() {
		Map<String,String> country = new LinkedHashMap<String,String>();
		country.put("TX", "Texas");
		country.put("NY", "NewYork");
		country.put("WC", "Washington");
		country.put("MD", "Maryland");

		return country;
	}
}
