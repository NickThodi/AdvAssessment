package trng.assessment.airline;


import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the FlightDetails database table.
 * 
 */
@Entity
@Table(name="FlightDetails")
@NamedQuery(name="FlightDetail.findAll", query="SELECT f FROM FlightDetail f")
public class FlightDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Temporal(TemporalType.DATE)
	@Column(name="flight_departure_date")
	private Date flightDepartureDate;

	@Column(name="available_seats")
	private int availableSeats;

	private BigDecimal price;

	//bi-directional many-to-one association to Flight
	@ManyToOne
	@JoinColumn(name="flight_id")
	private Flight flight;

	public FlightDetail() {
	}

	public Date getFlightDepartureDate() {
		return this.flightDepartureDate;
	}

	public void setFlightDepartureDate(Date flightDepartureDate) {
		this.flightDepartureDate = flightDepartureDate;
	}

	public int getAvailableSeats() {
		return this.availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public BigDecimal getPrice() {
		return this.price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Flight getFlight() {
		return this.flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

}