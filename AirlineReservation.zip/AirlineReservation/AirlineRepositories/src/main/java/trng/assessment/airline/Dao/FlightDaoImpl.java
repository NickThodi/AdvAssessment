package trng.assessment.airline.Dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import trng.assessment.airline.Flight;
import trng.assessment.excp.FlightNotFoundException;

@Repository
public class FlightDaoImpl  implements FlightDao {
	
	public Map<String, Flight> flightsMap = new HashMap<>();
	
	AtomicInteger flightId = new AtomicInteger(1);
	
	
	public FlightDaoImpl() {
		flightsMap.put("101", new Flight(101, 111, "American Airlines", new Date(), new Date(), "50 minutes", "EWR", "DFW", 50));
		flightsMap.put("202", new Flight(202, 222, "Southwest Airlines", new Date(), new Date(), "90 minutes", "PHX", "JFK", 100));
	}
	
	public void save(Flight flight) {
		flightsMap.toString();
	}

	public Flight findFlightByName(String airlineName){
	
		for (Map.Entry<String, Flight> userEntry : flightsMap.entrySet()) {
			if (userEntry.getValue().getAirlineName().equals(airlineName)) {
				return userEntry.getValue();
			}
		}
		return null;
	}
	
	public List<Flight> findFlightByAirlineNameStartsWith(String airlineName){
		List<Flight> searchList = new ArrayList<Flight>();
		for (Map.Entry<String, Flight> userEntry : flightsMap.entrySet()) {
			if (userEntry.getValue().getAirlineName().startsWith(airlineName)) {
				searchList.add(userEntry.getValue());
			}
		}
		
		return searchList;
	}
	
	public Flight findFlightById(int flightId) throws FlightNotFoundException{
		Flight matchUser = flightsMap.get(flightId);
		
		if(matchUser == null) {
			throw new FlightNotFoundException("User not found with given id: " + flightId);
		}
		
		return matchUser;
	}

	@Override
	public boolean deleteFlight(int flightId) {
		return flightsMap.remove(flightId) == null ? false : true;
	}


	public List<String> findAllFlightsByNames() {
		List<String> searchList = new ArrayList<String>();
		for (Map.Entry<String, Flight> userEntry : flightsMap.entrySet()) {
			searchList.add(userEntry.getValue().getAirlineName());
		}
		
		return searchList;
	}
	
	public List<Flight> findAllFlights() {
		return new ArrayList(flightsMap.values());
	}
}
